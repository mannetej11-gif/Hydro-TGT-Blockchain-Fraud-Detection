"""
metrics.py
----------
Standard fraud-detection classification metrics.
"""
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score


def compute_metrics(y_true, y_pred, y_prob=None) -> dict:
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    if y_prob is not None:
        try:
            metrics["roc_auc"] = roc_auc_score(y_true, y_prob)
        except ValueError:
            metrics["roc_auc"] = float("nan")  # only one class present in y_true
    return metrics


def print_metrics(metrics: dict, prefix: str = ""):
    line = " | ".join(f"{k}: {v:.4f}" for k, v in metrics.items())
    print(f"{prefix}{line}")

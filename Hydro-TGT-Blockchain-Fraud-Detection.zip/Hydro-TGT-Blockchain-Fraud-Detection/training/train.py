"""
train.py
--------
Trains HydroTGT on a prebuilt graph (see preprocessing/graph_builder.py).

Usage:
    python training/train.py --graph dataset/graph.pt --epochs 50 --out checkpoints/hydro_tgt.pt
"""
import argparse
import os
import sys

import torch
import torch.nn.functional as F

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "models"))
from classifier import HydroTGT  # noqa: E402
from metrics import compute_metrics, print_metrics  # noqa: E402


def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data = torch.load(args.graph, weights_only=False).to(device)

    model = HydroTGT(static_in_dim=data.x.shape[1]).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=5e-4)

    # class weighting — fraud is typically a small minority class
    train_y = data.y[data.train_mask]
    n_pos = (train_y == 1).sum().item()
    n_neg = (train_y == 0).sum().item()
    class_weights = torch.tensor(
        [1.0, max(n_neg / max(n_pos, 1), 1.0)], dtype=torch.float, device=device
    )

    best_val_f1 = 0.0
    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad()
        logits = model(data.x, data.edge_index, data.temporal_x)
        loss = F.cross_entropy(logits[data.train_mask], data.y[data.train_mask], weight=class_weights)
        loss.backward()
        optimizer.step()

        if epoch % args.eval_every == 0 or epoch == args.epochs:
            model.eval()
            with torch.no_grad():
                logits = model(data.x, data.edge_index, data.temporal_x)
                probs = F.softmax(logits, dim=1)[:, 1]
                preds = logits.argmax(dim=1)

                val_metrics = compute_metrics(
                    data.y[data.val_mask].cpu(), preds[data.val_mask].cpu(), probs[data.val_mask].cpu()
                )
                print(f"Epoch {epoch:03d} | loss {loss.item():.4f}")
                print_metrics(val_metrics, prefix="  val -> ")

                if val_metrics["f1"] >= best_val_f1:
                    best_val_f1 = val_metrics["f1"]
                    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
                    torch.save(model.state_dict(), args.out)

    print(f"Best val F1: {best_val_f1:.4f}. Model saved to {args.out}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", default="dataset/graph.pt")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--eval-every", type=int, default=5)
    parser.add_argument("--out", default="checkpoints/hydro_tgt.pt")
    args = parser.parse_args()
    train(args)


if __name__ == "__main__":
    main()

"""
evaluate.py
-----------
Loads a trained checkpoint and reports test-set metrics.

Usage:
    python training/evaluate.py --graph dataset/graph.pt --checkpoint checkpoints/hydro_tgt.pt
"""
import argparse
import os
import sys

import torch
import torch.nn.functional as F

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "models"))
from classifier import HydroTGT  # noqa: E402
from metrics import compute_metrics, print_metrics  # noqa: E402


def evaluate(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data = torch.load(args.graph, weights_only=False).to(device)

    model = HydroTGT(static_in_dim=data.x.shape[1]).to(device)
    model.load_state_dict(torch.load(args.checkpoint, map_location=device))
    model.eval()

    with torch.no_grad():
        logits = model(data.x, data.edge_index, data.temporal_x)
        probs = F.softmax(logits, dim=1)[:, 1]
        preds = logits.argmax(dim=1)

    test_metrics = compute_metrics(
        data.y[data.test_mask].cpu(), preds[data.test_mask].cpu(), probs[data.test_mask].cpu()
    )
    print_metrics(test_metrics, prefix="test -> ")
    return test_metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", default="dataset/graph.pt")
    parser.add_argument("--checkpoint", default="checkpoints/hydro_tgt.pt")
    args = parser.parse_args()
    evaluate(args)


if __name__ == "__main__":
    main()

"""
clean_data.py
--------------
Cleans raw transaction data into the standard schema used by the rest of the
pipeline:

    nodes.csv        wallet_id, first_seen_ts
    transactions.csv tx_id, src_wallet, dst_wallet, amount, timestamp
    labels.csv        wallet_id, label   (1=fraud, 0=normal, -1=unknown)

Supports three sources:
  --synthetic          generate a small random graph for pipeline testing
  --elliptic           remap the Elliptic Bitcoin dataset (expects dataset/raw/)
  (default)            expects nodes.csv/transactions.csv/labels.csv already
                        in --input, and just deduplicates / validates them
"""
import argparse
import os
import numpy as np
import pandas as pd


def generate_synthetic(n_wallets: int, n_tx: int, fraud_ratio: float = 0.08, seed: int = 42):
    rng = np.random.default_rng(seed)

    wallet_ids = [f"w{i}" for i in range(n_wallets)]
    nodes = pd.DataFrame({
        "wallet_id": wallet_ids,
        "first_seen_ts": rng.integers(0, 1_000_000, size=n_wallets),
    })

    n_fraud = int(n_wallets * fraud_ratio)
    fraud_wallets = set(rng.choice(wallet_ids, size=n_fraud, replace=False))
    labels = pd.DataFrame({
        "wallet_id": wallet_ids,
        "label": [1 if w in fraud_wallets else 0 for w in wallet_ids],
    })

    src = rng.choice(wallet_ids, size=n_tx)
    dst = rng.choice(wallet_ids, size=n_tx)
    # fraud wallets transact more frequently and in bursts -> gives the model signal
    amount = rng.exponential(scale=50.0, size=n_tx)
    timestamp = np.sort(rng.integers(0, 1_000_000, size=n_tx))
    transactions = pd.DataFrame({
        "tx_id": [f"tx{i}" for i in range(n_tx)],
        "src_wallet": src,
        "dst_wallet": dst,
        "amount": amount,
        "timestamp": timestamp,
    })

    return nodes, transactions, labels


def remap_elliptic(raw_dir: str):
    """
    Elliptic treats each *transaction* as a node. We keep that convention here
    (a 'wallet' in this pipeline == an Elliptic transaction node) since the
    edge list already represents transaction-to-transaction flow.
    """
    feats = pd.read_csv(os.path.join(raw_dir, "elliptic_txs_features.csv"), header=None)
    classes = pd.read_csv(os.path.join(raw_dir, "elliptic_txs_classes.csv"))
    edges = pd.read_csv(os.path.join(raw_dir, "elliptic_txs_edgelist.csv"))

    feats = feats.rename(columns={0: "txId", 1: "time_step"})
    node_ids = feats["txId"].astype(str)

    nodes = pd.DataFrame({
        "wallet_id": node_ids,
        "first_seen_ts": feats["time_step"],
    })

    label_map = {"1": 1, "2": 0, "unknown": -1}
    classes["class"] = classes["class"].astype(str).map(label_map)
    labels = pd.DataFrame({
        "wallet_id": classes["txId"].astype(str),
        "label": classes["class"],
    })

    transactions = pd.DataFrame({
        "tx_id": [f"tx{i}" for i in range(len(edges))],
        "src_wallet": edges["txId1"].astype(str),
        "dst_wallet": edges["txId2"].astype(str),
        "amount": 1.0,  # Elliptic doesn't expose raw amounts; use unit weight
        "timestamp": nodes.set_index("wallet_id").loc[edges["txId1"].astype(str), "first_seen_ts"].values,
    })

    return nodes, transactions, labels


def clean_and_validate(nodes, transactions, labels):
    nodes = nodes.drop_duplicates(subset="wallet_id").reset_index(drop=True)
    transactions = transactions.dropna(subset=["src_wallet", "dst_wallet"]).reset_index(drop=True)
    transactions = transactions[transactions["amount"] >= 0].reset_index(drop=True)
    labels = labels.drop_duplicates(subset="wallet_id").reset_index(drop=True)

    valid_wallets = set(nodes["wallet_id"])
    transactions = transactions[
        transactions["src_wallet"].isin(valid_wallets) & transactions["dst_wallet"].isin(valid_wallets)
    ].reset_index(drop=True)

    return nodes, transactions, labels


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="dataset/raw")
    parser.add_argument("--output", default="dataset/clean")
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--elliptic", action="store_true")
    parser.add_argument("--n-wallets", type=int, default=500)
    parser.add_argument("--n-tx", type=int, default=5000)
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    if args.synthetic:
        nodes, transactions, labels = generate_synthetic(args.n_wallets, args.n_tx)
    elif args.elliptic:
        nodes, transactions, labels = remap_elliptic(args.input)
    else:
        nodes = pd.read_csv(os.path.join(args.input, "nodes.csv"))
        transactions = pd.read_csv(os.path.join(args.input, "transactions.csv"))
        labels = pd.read_csv(os.path.join(args.input, "labels.csv"))

    nodes, transactions, labels = clean_and_validate(nodes, transactions, labels)

    nodes.to_csv(os.path.join(args.output, "nodes.csv"), index=False)
    transactions.to_csv(os.path.join(args.output, "transactions.csv"), index=False)
    labels.to_csv(os.path.join(args.output, "labels.csv"), index=False)

    print(f"Wrote {len(nodes)} nodes, {len(transactions)} transactions, {len(labels)} labels to {args.output}")


if __name__ == "__main__":
    main()

"""
feature_engineering.py
-----------------------
Turns cleaned transactions into:

1. Static per-wallet features  -> used as GNN node features
   [in_degree, out_degree, total_sent, total_received, avg_amount, tx_count]

2. Temporal per-wallet sequences -> used as Transformer input
   For each wallet, the last `seq_len` transactions it was involved in,
   as (amount, delta_time) pairs, padded/truncated to a fixed length.
"""
import numpy as np
import pandas as pd


def build_static_features(nodes: pd.DataFrame, transactions: pd.DataFrame) -> pd.DataFrame:
    wallets = nodes["wallet_id"].tolist()
    idx = {w: i for i, w in enumerate(wallets)}
    n = len(wallets)

    in_degree = np.zeros(n)
    out_degree = np.zeros(n)
    total_sent = np.zeros(n)
    total_received = np.zeros(n)
    tx_count = np.zeros(n)

    for _, row in transactions.iterrows():
        s, d, amt = idx.get(row["src_wallet"]), idx.get(row["dst_wallet"]), row["amount"]
        if s is not None:
            out_degree[s] += 1
            total_sent[s] += amt
            tx_count[s] += 1
        if d is not None:
            in_degree[d] += 1
            total_received[d] += amt
            tx_count[d] += 1

    avg_amount = np.divide(
        total_sent + total_received, np.maximum(tx_count, 1), out=np.zeros(n), where=tx_count > 0
    )

    feats = pd.DataFrame({
        "wallet_id": wallets,
        "in_degree": in_degree,
        "out_degree": out_degree,
        "total_sent": total_sent,
        "total_received": total_received,
        "avg_amount": avg_amount,
        "tx_count": tx_count,
    })
    return feats


def build_temporal_sequences(nodes: pd.DataFrame, transactions: pd.DataFrame, seq_len: int = 16):
    """
    Returns a numpy array of shape [num_wallets, seq_len, 2] where the last
    dimension is (amount, delta_time_since_previous_tx). Wallets with fewer
    than seq_len transactions are left-padded with zeros.
    """
    wallets = nodes["wallet_id"].tolist()
    idx = {w: i for i, w in enumerate(wallets)}
    n = len(wallets)

    per_wallet_events = {w: [] for w in wallets}
    for _, row in transactions.sort_values("timestamp").iterrows():
        for w in (row["src_wallet"], row["dst_wallet"]):
            if w in per_wallet_events:
                per_wallet_events[w].append((row["amount"], row["timestamp"]))

    sequences = np.zeros((n, seq_len, 2), dtype=np.float32)
    for w, events in per_wallet_events.items():
        if not events:
            continue
        events = events[-seq_len:]
        amounts = [e[0] for e in events]
        times = [e[1] for e in events]
        deltas = [0.0] + [times[i] - times[i - 1] for i in range(1, len(times))]
        arr = np.stack([amounts, deltas], axis=1)
        sequences[idx[w], -len(arr):, :] = arr

    return sequences


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="dataset/clean")
    parser.add_argument("--seq-len", type=int, default=16)
    args = parser.parse_args()

    nodes = pd.read_csv(f"{args.input}/nodes.csv")
    transactions = pd.read_csv(f"{args.input}/transactions.csv")

    static = build_static_features(nodes, transactions)
    static.to_csv(f"{args.input}/node_features.csv", index=False)

    temporal = build_temporal_sequences(nodes, transactions, seq_len=args.seq_len)
    np.save(f"{args.input}/temporal_sequences.npy", temporal)

    print(f"Static features: {static.shape}, Temporal sequences: {temporal.shape}")

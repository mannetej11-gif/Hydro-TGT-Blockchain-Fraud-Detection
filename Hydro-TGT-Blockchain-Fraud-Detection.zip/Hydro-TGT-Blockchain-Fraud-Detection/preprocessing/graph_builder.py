"""
graph_builder.py
-----------------
Assembles a single PyTorch Geometric `Data` object from the cleaned CSVs:

  - x            : [num_nodes, num_static_features]  (from feature_engineering.build_static_features)
  - temporal_x   : [num_nodes, seq_len, 2]            (from feature_engineering.build_temporal_sequences)
  - edge_index   : [2, num_edges]
  - edge_attr    : [num_edges, 1]  (transaction amount)
  - y            : [num_nodes]     (label: 1 fraud, 0 normal, -1 unknown)
  - train_mask / val_mask / test_mask : boolean masks over labeled nodes

Saved as a single .pt file consumed directly by training/train.py.
"""
import argparse
import numpy as np
import pandas as pd
import torch

from feature_engineering import build_static_features, build_temporal_sequences


def build_graph(nodes: pd.DataFrame, transactions: pd.DataFrame, labels: pd.DataFrame, seq_len: int = 16):
    wallets = nodes["wallet_id"].tolist()
    idx = {w: i for i, w in enumerate(wallets)}
    n = len(wallets)

    static = build_static_features(nodes, transactions).drop(columns=["wallet_id"]).values
    static = (static - static.mean(axis=0)) / (static.std(axis=0) + 1e-6)
    x = torch.tensor(static, dtype=torch.float)

    temporal = build_temporal_sequences(nodes, transactions, seq_len=seq_len)
    temporal_x = torch.tensor(temporal, dtype=torch.float)

    src = transactions["src_wallet"].map(idx).values
    dst = transactions["dst_wallet"].map(idx).values
    edge_index = torch.tensor(np.stack([src, dst]), dtype=torch.long)
    edge_attr = torch.tensor(transactions["amount"].values, dtype=torch.float).unsqueeze(1)

    label_map = dict(zip(labels["wallet_id"], labels["label"]))
    y = torch.tensor([label_map.get(w, -1) for w in wallets], dtype=torch.long)

    labeled = (y != -1).nonzero(as_tuple=True)[0]
    perm = labeled[torch.randperm(len(labeled))]
    n_train = int(0.7 * len(perm))
    n_val = int(0.15 * len(perm))

    train_mask = torch.zeros(n, dtype=torch.bool)
    val_mask = torch.zeros(n, dtype=torch.bool)
    test_mask = torch.zeros(n, dtype=torch.bool)
    train_mask[perm[:n_train]] = True
    val_mask[perm[n_train:n_train + n_val]] = True
    test_mask[perm[n_train + n_val:]] = True

    from torch_geometric.data import Data
    data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=y)
    data.temporal_x = temporal_x
    data.train_mask = train_mask
    data.val_mask = val_mask
    data.test_mask = test_mask
    return data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="dataset/clean")
    parser.add_argument("--output", default="dataset/graph.pt")
    parser.add_argument("--seq-len", type=int, default=16)
    args = parser.parse_args()

    nodes = pd.read_csv(f"{args.input}/nodes.csv")
    transactions = pd.read_csv(f"{args.input}/transactions.csv")
    labels = pd.read_csv(f"{args.input}/labels.csv")

    data = build_graph(nodes, transactions, labels, seq_len=args.seq_len)
    torch.save(data, args.output)
    print(data)
    print(f"Saved graph to {args.output}")


if __name__ == "__main__":
    main()

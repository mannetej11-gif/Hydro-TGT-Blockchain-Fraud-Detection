# Dataset

Raw and processed data files are **not committed** to this repo (too large / licensed
separately). Set it up as follows.

## Option A — Elliptic Bitcoin Dataset (recommended)

1. Download from Kaggle: https://www.kaggle.com/datasets/ellipticco/elliptic-data-set
2. You'll get:
   - `elliptic_txs_features.csv` — 203,769 transactions × 166 features
   - `elliptic_txs_classes.csv` — labels (`1`=illicit, `2`=licit, `unknown`)
   - `elliptic_txs_edgelist.csv` — transaction → transaction edges
3. Place all three files in `dataset/raw/`.
4. `preprocessing/clean_data.py` remaps these into the `nodes.csv` / `transactions.csv` /
   `labels.csv` schema this project expects (transaction nodes are treated as wallets for
   this project's purposes — see comments in that file for the exact mapping).

## Option B — Your own wallet-transaction data

Provide three CSVs in `dataset/raw/` with these columns:

| File | Columns |
|---|---|
| `nodes.csv` | `wallet_id, first_seen_ts` |
| `transactions.csv` | `tx_id, src_wallet, dst_wallet, amount, timestamp` |
| `labels.csv` | `wallet_id, label` (1=fraud, 0=normal, -1=unknown) |

## Option C — Synthetic data (for testing the pipeline without any dataset)

Run:

```bash
python preprocessing/clean_data.py --synthetic --output dataset/clean --n-wallets 500 --n-tx 5000
```

This generates a small random wallet graph so you can verify the full pipeline
(graph building → training → evaluation) runs end-to-end before plugging in real data.

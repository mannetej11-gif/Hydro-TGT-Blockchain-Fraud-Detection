"""
app.py
------
Streamlit demo for Hydro-TGT.

Run with:
    streamlit run app/app.py
"""
import streamlit as st
from predict import HydroTGTPredictor

st.set_page_config(page_title="Hydro-TGT: Fraud Detection", page_icon="🔎")
st.title("🔎 Hydro-TGT — Blockchain Fraud Detection")
st.caption("GNN + Transformer hybrid model for flow-aware fraud detection")

GRAPH_PATH = "dataset/graph.pt"
CHECKPOINT_PATH = "checkpoints/hydro_tgt.pt"
WALLET_IDS_PATH = "dataset/clean/nodes.csv"


@st.cache_resource
def load_predictor():
    return HydroTGTPredictor(GRAPH_PATH, CHECKPOINT_PATH, WALLET_IDS_PATH)


try:
    predictor = load_predictor()
except FileNotFoundError:
    st.error(
        "No trained model found yet. Run the pipeline first:\n\n"
        "1. `python preprocessing/clean_data.py --synthetic --output dataset/clean`\n"
        "2. `python preprocessing/graph_builder.py --input dataset/clean --output dataset/graph.pt`\n"
        "3. `python training/train.py --graph dataset/graph.pt --out checkpoints/hydro_tgt.pt`"
    )
    st.stop()

tab1, tab2 = st.tabs(["Lookup a wallet", "Top risky wallets"])

with tab1:
    wallet_id = st.text_input("Wallet ID", placeholder="e.g. w42")
    if st.button("Check", type="primary") and wallet_id:
        try:
            prob = predictor.predict_by_wallet_id(wallet_id)
            st.metric("Fraud probability", f"{prob:.1%}")
            if prob > 0.5:
                st.error("⚠️ Flagged as likely fraudulent")
            else:
                st.success("✅ Looks normal")
        except ValueError as e:
            st.warning(str(e))

with tab2:
    k = st.slider("Show top N riskiest wallets", 5, 50, 10)
    results = predictor.top_risky_wallets(k)
    st.table(
        {
            "Node index": [r[0] for r in results],
            "Fraud probability": [f"{r[1]:.1%}" for r in results],
        }
    )

"""
predict.py
----------
Loads the trained graph + model once and exposes a simple lookup function
for the Streamlit app: given a wallet_id, return its fraud probability.
"""
import os
import sys

import torch
import torch.nn.functional as F

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "models"))
from classifier import HydroTGT  # noqa: E402


class HydroTGTPredictor:
    def __init__(self, graph_path: str, checkpoint_path: str, wallet_ids_path: str = None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.data = torch.load(graph_path, weights_only=False).to(self.device)

        self.model = HydroTGT(static_in_dim=self.data.x.shape[1]).to(self.device)
        self.model.load_state_dict(torch.load(checkpoint_path, map_location=self.device))
        self.model.eval()

        with torch.no_grad():
            logits = self.model(self.data.x, self.data.edge_index, self.data.temporal_x)
            self.probs = F.softmax(logits, dim=1)[:, 1].cpu()

        # optional: map wallet_id strings -> node index, if you saved this during graph building
        self.wallet_index = None
        if wallet_ids_path and os.path.exists(wallet_ids_path):
            import pandas as pd
            ids = pd.read_csv(wallet_ids_path)["wallet_id"].tolist()
            self.wallet_index = {w: i for i, w in enumerate(ids)}

    def predict_by_index(self, node_idx: int) -> float:
        return float(self.probs[node_idx])

    def predict_by_wallet_id(self, wallet_id: str) -> float:
        if self.wallet_index is None or wallet_id not in self.wallet_index:
            raise ValueError(f"Unknown wallet_id: {wallet_id}")
        return self.predict_by_index(self.wallet_index[wallet_id])

    def top_risky_wallets(self, k: int = 10):
        top_idx = torch.topk(self.probs, k).indices.tolist()
        return [(idx, self.predict_by_index(idx)) for idx in top_idx]

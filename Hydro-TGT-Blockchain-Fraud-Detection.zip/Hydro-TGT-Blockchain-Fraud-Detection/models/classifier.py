"""
classifier.py
-------------
HydroTGT: fuses the GNN spatial embedding with the Transformer temporal
embedding and classifies each wallet as fraud (1) or normal (0).
"""
import torch
import torch.nn as nn

from gnn import GNNEncoder
from transformer import TemporalTransformer


class HydroTGT(nn.Module):
    def __init__(self, static_in_dim: int, gnn_hidden: int = 64, gnn_out: int = 64,
                 temporal_d_model: int = 64, num_classes: int = 2, dropout: float = 0.3):
        super().__init__()
        self.gnn = GNNEncoder(static_in_dim, gnn_hidden, gnn_out, dropout=dropout)
        self.temporal = TemporalTransformer(input_dim=2, d_model=temporal_d_model)

        fused_dim = gnn_out + temporal_d_model
        self.classifier = nn.Sequential(
            nn.Linear(fused_dim, fused_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(fused_dim // 2, num_classes),
        )

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor, temporal_x: torch.Tensor) -> torch.Tensor:
        spatial_emb = self.gnn(x, edge_index)          # [N, gnn_out]
        temporal_emb = self.temporal(temporal_x)         # [N, temporal_d_model]
        fused = torch.cat([spatial_emb, temporal_emb], dim=1)
        logits = self.classifier(fused)                   # [N, num_classes]
        return logits

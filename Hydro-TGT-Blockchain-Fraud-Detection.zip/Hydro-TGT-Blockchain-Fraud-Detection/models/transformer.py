"""
transformer.py
--------------
Temporal encoder: embeds each wallet's recent transaction sequence
(amount, delta_time) and runs it through a standard Transformer encoder to
capture evolving/bursty fraud patterns over time. A learned CLS token is
prepended and its output embedding is used as the wallet's temporal summary.
"""
import torch
import torch.nn as nn


class TemporalTransformer(nn.Module):
    def __init__(self, input_dim: int = 2, d_model: int = 64, nhead: int = 4,
                 num_layers: int = 2, dim_feedforward: int = 128, dropout: float = 0.1):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, d_model)
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_model))
        self.pos_embedding = None  # created lazily once seq_len is known

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=dim_feedforward,
            dropout=dropout, batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.d_model = d_model

    def _positional_embedding(self, seq_len: int, device):
        if self.pos_embedding is None or self.pos_embedding.shape[1] != seq_len + 1:
            self.pos_embedding = nn.Parameter(
                torch.randn(1, seq_len + 1, self.d_model, device=device)
            )
        return self.pos_embedding

    def forward(self, temporal_x: torch.Tensor) -> torch.Tensor:
        """
        temporal_x: [num_nodes, seq_len, input_dim]
        returns:    [num_nodes, d_model]  (embedding from the CLS position)
        """
        batch_size, seq_len, _ = temporal_x.shape
        h = self.input_proj(temporal_x)                       # [N, seq_len, d_model]
        cls = self.cls_token.expand(batch_size, -1, -1)        # [N, 1, d_model]
        h = torch.cat([cls, h], dim=1)                          # [N, seq_len+1, d_model]
        h = h + self._positional_embedding(seq_len, h.device)
        out = self.encoder(h)                                   # [N, seq_len+1, d_model]
        return out[:, 0, :]  # CLS embedding

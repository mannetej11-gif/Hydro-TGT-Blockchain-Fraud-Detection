"""
gnn.py
------
Spatial encoder: a 2-layer GraphSAGE network that produces a node embedding
capturing each wallet's structural position in the transaction graph.

Swap `SAGEConv` for `GATConv` (PyTorch Geometric) if you want an attention-based
variant later — the interface stays identical.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv


class GNNEncoder(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int = 64, out_channels: int = 64, dropout: float = 0.2):
        super().__init__()
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, out_channels)
        self.dropout = dropout

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        h = self.conv1(x, edge_index)
        h = F.relu(h)
        h = F.dropout(h, p=self.dropout, training=self.training)
        h = self.conv2(h, edge_index)
        return h  # [num_nodes, out_channels]
